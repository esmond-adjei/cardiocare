from pathlib import Path

import numpy as np
import tensorflow as tf
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import ECGClassification
from .serializers import ECGClassificationSerializer

# Load the TensorFlow Lite model
BASE_DIR = Path(__file__).parent
interpreter = tf.lite.Interpreter(model_path=f"{BASE_DIR}/ecg_arrhythmia.tflite")
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

@api_view(['GET'])
def home(request):
    return Response('classifier is online', status=status.HTTP_200_OK)
    

@api_view(['POST'])
def classify_ecg(request):
    if request.method == 'POST':
        # Extract ECG data from request
        ecg_data = request.data #.get('ecg_data', [])
        
        if len(ecg_data) != 187:
            return Response({"error": "ECG data must have 187 points"}, status=status.HTTP_400_BAD_REQUEST)

        # Prepare input data
        input_data = np.array(ecg_data, dtype=np.float32).reshape(1, 187, 1, 1)
        
        # Set input tensor
        interpreter.set_tensor(input_details[0]['index'], input_data)
        
        # Run inference
        interpreter.invoke()
        
        # Get output tensor
        output_data = interpreter.get_tensor(output_details[0]['index'])
        
        # Process results
        class_names = ["Normal", "Supraventricular", "Ventricular", "Fusion", "Unknown"]
        classification_result = {class_names[i]: float(output_data[0][i]) for i in range(5)}
        
        # Save to database
        ecg_classification = ECGClassification(
            input_data=ecg_data,
            classification_result=classification_result
        )
        ecg_classification.save()
        
        # Prepare response
        serializer = ECGClassificationSerializer(ecg_classification)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
