from django.apps import AppConfig


class EcgClassifierConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ecg_classifier'
