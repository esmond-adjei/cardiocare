from django.db import models

class ECGClassification(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    input_data = models.JSONField()
    classification_result = models.JSONField()