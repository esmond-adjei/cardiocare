from rest_framework import serializers
from .models import ECGClassification

class ECGClassificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ECGClassification
        fields = ['id', 'timestamp', 'classification_result']
